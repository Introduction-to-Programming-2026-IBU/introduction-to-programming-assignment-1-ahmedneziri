/**
 * Exercise 4: JavaScript & the DOM
 * ==================================
 * Complete each task below. Read the README.md for full instructions.
 * Open the browser console (F12) to debug.
 */

// ============================================================
// TASK 1 — Console Warmup
// ============================================================

// TODO 1a: Select the element with id "main-title" and change its text to
//          "DOM Mastery 🚀" using .textContent
document.querySelector('#main-title').textContent = "DOM Mastery 🚀";

// TODO 1b: Select ALL elements with class "card", log how many there are
const cards = document.querySelectorAll('.card');
console.log(cards.length);

// TODO 1c: Select the element with id "target-box" and change its
//          background color to any color you like using style.backgroundColor
document.querySelector('#target-box').style.backgroundColor = '#eef7ee';


// ============================================================
// TASK 2 — Click Counter
// ============================================================

// Step 1: Get references to the elements you need
const countDisplay = document.querySelector('#count-display');
// TODO: get references to the three buttons
const btnIncrement = document.querySelector('#btn-increase');
const btnDecrement = document.querySelector('#btn-decrease');
const btnReset = document.querySelector('#btn-reset');

// Step 2: Track the count
let count = 0;

// Helper: update the display and apply color classes
function updateCountDisplay() {
  // TODO: Set countDisplay.textContent to count
  countDisplay.textContent = count;
  
  // TODO: If count is 0, add class 'zero' to countDisplay (and remove 'high')
  // TODO: If count > 5, add class 'high' (and remove 'zero')
  // TODO: Otherwise, remove both classes
  if (count === 0) {
    countDisplay.classList.add('zero');
    countDisplay.classList.remove('high');
  } else if (count > 5) {
    countDisplay.classList.add('high');
    countDisplay.classList.remove('zero');
  } else {
    countDisplay.classList.remove('zero', 'high');
  }
}

// TODO: Add click event listener to increment button
btnIncrement.addEventListener('click', () => {
  count++;
  updateCountDisplay();
});

// TODO: Add click event listener to decrement button (don't go below 0!)
btnDecrement.addEventListener('click', () => {
  if (count > 0) {
    count--;
    updateCountDisplay();
  }
});

// TODO: Add click event listener to reset button
btnReset.addEventListener('click', () => {
  count = 0;
  updateCountDisplay();
});

// Initialize display
updateCountDisplay();


// ============================================================
// TASK 3 — Dynamic List Builder
// ============================================================

const listInput = document.querySelector('#list-input');
const dynamicList = document.querySelector('#dynamic-list');

// TODO: Add click listener to '#btn-add-item'
// Inside the listener:
//   1. Get the value from listInput
//   2. If it's empty (after .trim()), don't add — shake the input or alert
//   3. Create a new <li> element
//   4. Set its text content (include a × delete button)
//   5. Append the <li> to dynamicList
//   6. Clear listInput.value and focus it
document.querySelector('#btn-add-item').addEventListener('click', () => {
  const textValue = listInput.value.trim();
  
  if (textValue === '') {
    listInput.classList.remove('shake');
    void listInput.offsetWidth; // Force DOM reflow
    listInput.classList.add('shake');
    return;
  }
  
  const newLi = document.createElement('li');
  newLi.innerHTML = `<span>${textValue}</span> <button class="delete-btn">×</button>`;
  
  dynamicList.appendChild(newLi);
  
  listInput.value = '';
  listInput.focus();
});

// TODO: Handle delete buttons — you'll need event delegation OR
//       attach a listener each time you create a new item.
//       Hint for event delegation:
//       dynamicList.addEventListener('click', function(event) {
//         if (event.target.classList.contains('delete-btn')) { ... }
//       });

// Wire up delete buttons that already exist in the HTML
dynamicList.addEventListener('click', function(event) {
  // TODO: if the clicked element has class 'delete-btn', remove its parent <li>
  if (event.target.classList.contains('delete-btn')) {
    event.target.closest('li').remove();
  }
});


// ============================================================
// TASK 4 — Show / Hide Toggle
// ============================================================

const toggleBtn = document.querySelector('#btn-toggle');
const detailsDiv = document.querySelector('.details');

// TODO: Add click listener to toggleBtn
// Inside:
//   - Toggle the 'hidden' class on detailsDiv
//   - Change button text: "Show Details" ↔ "Hide Details"
toggleBtn.addEventListener('click', () => {
  detailsDiv.classList.toggle('hidden');
  
  if (detailsDiv.classList.contains('hidden')) {
    toggleBtn.textContent = 'Show Details';
  } else {
    toggleBtn.textContent = 'Hide Details';
  }
});


// ============================================================
// TASK 5 — Color Mixer
// ============================================================

const sliderR = document.querySelector('#slider-r');
const sliderG = document.querySelector('#slider-g');
const sliderB = document.querySelector('#slider-b');
const colorPreview = document.querySelector('#color-preview');
const hexDisplay = document.querySelector('#hex-display');

function updateColor() {
  const r = parseInt(sliderR.value);
  const g = parseInt(sliderG.value);
  const b = parseInt(sliderB.value);

  // TODO: Update the text of #val-r, #val-g, #val-b spans
  document.querySelector('#val-r').textContent = r;
  document.querySelector('#val-g').textContent = g;
  document.querySelector('#val-b').textContent = b;

  // TODO: Set colorPreview's background to rgb(r, g, b)
  colorPreview.style.backgroundColor = `rgb(${r}, ${g}, ${b})`;

  // TODO: Convert each value to a 2-digit hex string and update #hex-display
  // Hint: const hex = value.toString(16).padStart(2, '0');
  const hexR = r.toString(16).padStart(2, '0');
  const hexG = g.toString(16).padStart(2, '0');
  const hexB = b.toString(16).padStart(2, '0');
  hexDisplay.textContent = `#${hexR}${hexG}${hexB}`.toUpperCase();
}

// TODO: Add 'input' event listeners to all three sliders that call updateColor()
sliderR.addEventListener('input', updateColor);
sliderG.addEventListener('input', updateColor);
sliderB.addEventListener('input', updateColor);

// Initialize
updateColor();