#include <ctype.h>
#include <cs50.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

int count_letters(string text);
int count_words(string text);
int count_sentences(string text);

int main(void)
{

    string text = get_string("Text: ");

    // Count letters, words, and sentences
    int letters   = count_letters(text);
    int words     = count_words(text);
    int sentences = count_sentences(text);


    float L = 100.0 * letters / words; //
    float S = 100.0 * sentences / words; //


    int index = round(0.0588 * L - 0.296 * S - 15.8); //


    if (index >= 16)
    {
        printf("Grade 16+\n"); //
    }
    else if (index < 1)
    {
        printf("Before Grade 1\n"); //
    }
    else
    {
        printf("Grade %i\n", index); //
    }
}

int count_letters(string text)
{
    int count = 0;
    for (int i = 0, n = strlen(text); i < n; i++)
    {

        if (isalpha(text[i]))
        {
            count++;
        }
    }
    return count;
}


int count_words(string text)
{

    int count = 1; 
    for (int i = 0, n = strlen(text); i < n; i++)
    {

        if (text[i] == ' ')
        {
            count++;
        }
    }
    return count;
}


int count_sentences(string text)
{
    int count = 0;
    for (int i = 0, n = strlen(text); i < n; i++)
    {

        if (text[i] == '.' || text[i] == '!' || text[i] == '?')
        {
            count++;
        }
    }
    return count;
}